# Offensive Security Portfolio

SEO-ready, responsive GitHub Pages portfolio for Sabuj Paul.

## Included
- Semantic HTML and responsive layout for phone, tablet and desktop
- SEO title, description, keywords, canonical URL and robots directives
- Open Graph and Twitter metadata
- JSON-LD `Person` and `WebSite` structured data
- XML sitemap and robots.txt
- Web App Manifest
- Social preview image
- Accessible skip link, navigation labels and reduced-motion support
- Live GitHub public-repository cards and statistics
- GitHub Pages deployment workflow
- Downloadable CV

## Important URL

This project is configured for:

https://sabuj-paul100.github.io/offensive-security.github.io/

If you later move to a custom domain, update the canonical URL, Open Graph URLs, Twitter image URL, sitemap and manifest `start_url`.

## GitHub Pages

GitHub Pages can publish an existing repository. The included workflow can deploy the root of the repository through GitHub Actions.

## Search visibility

This site contains the technical SEO foundation, but no HTML metadata can guarantee a Google ranking or immediate indexing. After deployment:
1. Verify the live URL in Google Search Console.
2. Submit `sitemap.xml`.
3. Request indexing for the homepage.
4. Keep the site crawlable and publicly accessible.
5. Add genuine project pages/write-ups over time; unique useful content is more valuable than keyword stuffing.

## GitHub repository metadata

The current repository page has no description or topics. Recommended repository description:

"Professional cybersecurity & ethical hacking portfolio — web security, vulnerability assessment, network security, OWASP, security research and practical projects."

Suggested topics:
`cybersecurity`, `ethical-hacking`, `penetration-testing`, `web-security`, `network-security`, `owasp`, `vulnerability-assessment`, `security-research`, `portfolio`, `github-pages`

Do not claim certifications or professional experience that you cannot substantiate.
