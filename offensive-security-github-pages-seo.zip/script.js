const GITHUB_USERNAME="sabuj-Paul100";
const REPO_LIMIT=6;
const $=s=>document.querySelector(s);
document.addEventListener("DOMContentLoaded",()=>{
  $("#year").textContent=new Date().getFullYear();
  const header=$("#header"),menu=$("#menu"),nav=$("#navlinks");
  addEventListener("scroll",()=>header.classList.toggle("scrolled",scrollY>20),{passive:true});
  menu.addEventListener("click",()=>{const open=nav.classList.toggle("open");menu.setAttribute("aria-expanded",open)});
  nav.querySelectorAll("a").forEach(a=>a.addEventListener("click",()=>{nav.classList.remove("open");menu.setAttribute("aria-expanded","false")}));
  loadGithub(); initMap();
});
const esc=v=>String(v??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
async function loadGithub(){
  const grid=$("#projectsGrid");
  try{
    const r=await fetch(`https://api.github.com/users/${encodeURIComponent(GITHUB_USERNAME)}/repos?sort=updated&per_page=100`);
    if(!r.ok)throw new Error("GitHub API error");
    const all=(await r.json()).filter(x=>!x.archived), shown=all.slice(0,REPO_LIMIT);
    $("#repoCount").textContent=all.length;
    $("#starCount").textContent=all.reduce((n,x)=>n+x.stargazers_count,0);
    $("#forkCount").textContent=all.reduce((n,x)=>n+x.forks_count,0);
    $("#languageCount").textContent=new Set(all.map(x=>x.language).filter(Boolean)).size;
    grid.innerHTML=shown.length?shown.map(x=>`<article class="repo"><small>${x.fork?"FORK":"REPOSITORY"} / ${(x.visibility||"PUBLIC").toUpperCase()}</small><h3>${esc(x.name)}</h3><p>${esc(x.description||"No repository description yet.")}</p><div class="repo-meta"><span>${esc(x.language||"Mixed")}</span><span>★ <b>${x.stargazers_count}</b></span><span>⑂ <b>${x.forks_count}</b></span></div><a href="${esc(x.html_url)}" target="_blank" rel="noopener noreferrer">Open repository ↗</a></article>`).join(""):'<div class="loading">NO PUBLIC REPOSITORIES FOUND.</div>';
  }catch(e){grid.innerHTML='<div class="loading">GITHUB FEED TEMPORARILY UNAVAILABLE. PROJECTS REMAIN ACCESSIBLE THROUGH THE GITHUB PROFILE.</div>'}
}
function initMap(){
  const c=$("#threatMap"),ctx=c.getContext("2d");let p=[],W,H;
  const resize=()=>{W=innerWidth;H=innerHeight;c.width=W*devicePixelRatio;c.height=H*devicePixelRatio;ctx.setTransform(devicePixelRatio,0,0,devicePixelRatio,0,0);p=Array.from({length:Math.min(34,Math.floor(W/38))},()=>({x:Math.random()*W,y:Math.random()*H,vx:(Math.random()-.5)*.12,vy:(Math.random()-.5)*.12}))};
  const draw=()=>{ctx.clearRect(0,0,W,H);for(const a of p){a.x+=a.vx;a.y+=a.vy;if(a.x<0||a.x>W)a.vx*=-1;if(a.y<0||a.y>H)a.vy*=-1}
  for(let i=0;i<p.length;i++)for(let j=i+1;j<p.length;j++){const a=p[i],b=p[j],d=Math.hypot(a.x-b.x,a.y-b.y);if(d<135){ctx.strokeStyle=`rgba(83,230,209,${.065*(1-d/135)})`;ctx.beginPath();ctx.moveTo(a.x,a.y);ctx.lineTo(b.x,b.y);ctx.stroke()}}
  for(const a of p){ctx.fillStyle="rgba(83,230,209,.18)";ctx.beginPath();ctx.arc(a.x,a.y,1.5,0,Math.PI*2);ctx.fill()}requestAnimationFrame(draw)};
  addEventListener("resize",resize,{passive:true});resize();draw();
}